import React from 'react'
import Modal from 'react-bootstrap/Modal';
import { dateArray, monthArray, yearArray } from '../../../Helper/Datehelper';
import './SignUp.scss'

function SignUp(props) {


 
  return (
    <Modal
      show={props.modal}
      onHide={props.handlemodal}
      dialogClassName='sign_upModal'
      centered  
     >
    <Modal.Header closeButton>
       <div className="modal-top">
        <h2 className='Sign-Up font-Helvetica font-bold'> Sign Up</h2>
           <span className='quick-and-easy'>It's quick and easy.</span>
        </div>
    </Modal.Header>
    
    <Modal.Body>
         <div className="signup_form ">
              <form action="">
                   <div className="flex items-center justify-between">
                        <input className='basis-[49%]' type="text" placeholder='First name' />
                        <input className='basis-[49%]' type="text" placeholder='Surname' />
                   </div>
                   <div className='my-2'>
                       <input className='w-full' type="text" placeholder='Mobile number or email' />
                   </div>
                   <div className='my-2'>
                       <input className='w-full' type="password" placeholder='New password' />
                   </div>
                   <div>Date of birth</div>
                   <div className='my-2 flex justify-between gap-x-2'> 
                        <select className='grow' name="" id="">
                           {
                            dateArray.map( i => 
                                <option value={i}>{i}</option>
                              )
                           }
                        </select> 
                        <select className='grow' name="" id="">
                           {
                            monthArray.map( i => 
                                <option value={i}>{i}</option>
                              )
                           }
                        </select> 
                        <select className='grow' name="" id="">
                           {
                            yearArray.map( i => 
                                <option value={i}>{i}</option>
                              )
                           }
                        </select>
                        
                   </div>
                   <div>Gender</div>
                   <div className='my-2 flex items-center gap-x-2'>
                         <div className='radio-wrap grow border flex justify-between items-center p-2'>
                           <label htmlFor="female">Female</label>
                           <input type="radio" name="gender" id='female' value="female" />
                         </div>
                         <div className='radio-wrap grow border flex justify-between items-center p-2'>
                           <label htmlFor="male">Male</label>
                           <input type="radio" name="gender" id='male' value="male" />
                         </div>

                         <div className='radio-wrap grow border flex justify-between items-center p-2'>
                           <label htmlFor="custom">Custom</label>
                           <input type="radio" name="gender" id='custom' value="custom" />
                         </div>        
                   </div>
                   <div className='my-2'>
                        <p className='text-[11px]'>People who use our service may have uploaded your contact information to Facebook. <a href="#">Learn more.</a></p>
                   </div> 
                   <div className='my-2'>
                        <p className='text-[11px]'>By clicking Sign Up, you agree to our <a href="#">Terms,</a>  <a href="#">Privacy Policy</a> and <a href="#">Cookies Policy.</a>  You may receive SMS notifications from us and can opt out at any time.</p>
                   </div>
                   <div className="submit-btn text-center">
                      <input type="submit" className='text-[17px] h-[36px] px-[16px] font-bold text-[#fff] hover:text-[#fff] inline-block w-[197px]' value='Sign Up' />
                  </div>
              </form>
         </div>
    </Modal.Body>
    </Modal>
  )
}

export default SignUp